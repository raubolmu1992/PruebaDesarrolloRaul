Documento Genérico
Versión No: 1.0
Fecha : 17-Feb-2021	Prueba Programador Backend
Realizado por: Raúl Eduardo Bolaños Muñoz

*************************************************************************
Para configurar el proyecto leer el archivo llamado: Documentacion.docx *
el cual se encuentra en la carpeta raiz.                                *
*************************************************************************
