<!doctype html>
<html lang="es">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <!-- Font Roboto CSS -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
    <style>body{font-family:"Roboto" !important;}</style>

    <title>Lista de usuarios</title>
  </head>
  <body>

    <div class="container">

        <h1 class="mt-5"><div align="center"> Iniciar Sesión</div></h1>
      
     
         <div class="container" align="center">  
           <br /><br /><br />  
           <form method="post" action="<?php echo base_url(); ?>login">  
                <div class="form-group">  
                     <label>Ingrese su Usuario</label>  
                     <input type="text" style="width : 300px; heigth : 10px" name="usuario" class="form-control" />  
                     <span class="text-danger"><?php echo form_error('usuario'); ?>

</span>                 
                </div>  
                <div class="form-group">  
                     <label>Ingrese su Contraseña</label>  
                      <input type="password" name="password" style="width : 300px; heigth : 10px" name="password" class="form-control" />  
                     <span class="text-danger"><?php echo form_error('password'); ?>

</span>  
                </div>  
                <div class="form-group">  
                     <input type="submit" name="insert" value="Login" class="btn btn-info" />  
                     <?php  
                          echo '<label class="text-danger">'.$this->session->flashdata

("error").'</label>';  
                     ?>  
                </div>  
           </form>  
      </div>  
        
        
    </div>

    <script src="https://unpkg.com/ionicons@5.1.2/dist/ionicons.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>

    <script>
        
        <?php if($this->session->flashdata("success")): ?>

            Swal.fire({
                icon: 'success',
                title: 'Ejecución Exitosa...',
                text: '<?php echo $this->session->flashdata("success"); ?>',
            });
        <?php endif; ?>

    </script>
  </body>
</html>