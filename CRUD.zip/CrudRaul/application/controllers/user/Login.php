<?php  
 defined('BASEPATH') OR exit('No direct script access allowed');  
 class Login extends CI_Controller {  
      //functions  

  public function __construct()
  {
    parent::__construct();
    $this->load->model("User_model");
  }

  public function index()
  {
    $this->load->view('login');
  }

      function login()  
      {  
           //http://localhost/tutorial/codeigniter/main/login  
           $data['title'] = 'CodeIgniter Simple Login Form With Sessions';  
           $this->load->view("user/Login", $data);  
      }  
      function login_validation()  
      {  
           $this->load->library('form_validation');  
           $this->form_validation->set_rules('usuario', 'usuario', 'required');  
           $this->form_validation->set_rules('password', 'password', 'required');  
           if($this->form_validation->run())  
           {  
                //true  
                $usuario =  $this->input->post('usuario');  
                $password = $this->input->post('password');  
                //model function  
                $this->load->model('User_model');  
                if($this->User_model->can_login($usuario, $password))  
                {  
                     $session_data = array(  
                          'usuario'     =>     $usuario  
                     );  
                     $this->session->set_userdata($session_data); 
                   redirect(base_url().'tareas'); 
                }  
                else  
                {  
                     $this->session->set_flashdata('error', 'Invalid usuario and Password');  
                     redirect(base_url() . 'usuarios');  
                }  
           }  
           else  
           {  
                //false  
                $this->login();  
           }  
      }  
      function enter(){  
           if($this->session->userdata('usuario') != '')  
           {  
                echo '<h2>Welcome - '.$this->session->userdata('usuario').'</h2>';  
                echo '<label><a href="'.base_url

().'main/logout">Logout</a></label>';  
           }  
           else  
           {  
                redirect(base_url() . 'login');  
           }  
      }  
      function logout()  
      {  
           echo "Error Login";
           $this->session->unset_userdata('usuario');  
           redirect(base_url() . 'login');  
        
      }  
 }  