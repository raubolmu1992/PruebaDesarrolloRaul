<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Add extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model("User_model");
	}

	public function index()
	{
		$this->load->view('user/add');
	}

	public function save(){
		$fullName = $this->input->post("fullName");
		$email = $this->input->post("email");
                $usuario = $this->input->post("usuario");
		$password = $this->input->post("password");
		$repeatPassord = $this->input->post("repeatPassord");
                $estado = $this->input->post("estado");
                $descripcion = $this->input->post("descripcion");
            
            
		$this->form_validation->set_rules('fullName', 'Nombre completo', 'required|min_length[3]');
		$this->form_validation->set_rules('email', 'Correo eléctronico', 'required|valid_email|is_unique[usuarios.email]');
		$this->form_validation->set_rules('password', 'Password', 'required|min_length[4]');
		$this->form_validation->set_rules('repeatPassord', 'Confirma contraseña', 'required|matches[password]');

		if ($this->form_validation->run() == FALSE){
			$this->load->view('user/add');
			echo "Error de ingreso de datos";
		}
		else{
echo "Continua proceso de registro de datos";
			$data = array(
				"full_name"=>$fullName,
				"email"=>$email,
                                "usuario"=>$usuario,
				//"password"=>md5($password),
                                "password"=>($password),
                                "estado"=>$estado,
                                "descripcion"=>$descripcion,
			);
			
			$this->User_model->save($data);
			$this->session->set_flashdata('success', 'Se guardo los datos correctamente');
			redirect(base_url()."usuarios");
		}
	}
}
