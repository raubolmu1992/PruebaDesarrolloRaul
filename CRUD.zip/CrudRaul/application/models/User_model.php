<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

    public function save($data){
        $this->db->query("ALTER TABLE usuarios AUTO_INCREMENT 1");
        $this->db->insert("usuarios",$data);
    }

    public function getUsers(){
        $this->db->select("*");
        $this->db->from("usuarios");
        $results=$this->db->get();
        return $results->result();
    }

    public function getUser($id){
        $this->db->select("u.id, u.full_name, u.email, u.usuario, u.estado, u.descripcion");
        $this->db->from("usuarios u");
        $this->db->where("u.id",$id);
        $result=$this->db->get();
        return $result->row();
    }

     public function getEstado(){
     $this->db->select("*");
        $this->db->from("usuarios");
        $this->db->where("estado LIKE 'Si'");
        $results=$this->db->get();
        return $results->result();
    }


     public function getFecha(){
        $this->db->order_by("modified_at", "desc");
        $this->db->from("usuarios");
        $results=$this->db->get();
        return $results->result(); 
    }
    
    public function update($data,$id){
        $this->db->where("id",$id);
        $this->db->update("usuarios",$data);
    }

    public function delete($id){
        $this->db->where("id",$id);
        $this->db->delete("usuarios");
    }
    
     public function can_login($usuario, $password)  
      {  
           $this->db->where('usuario', $usuario);  
           $this->db->where('password', $password);  
           $query = $this->db->get('usuarios');  
          // SELECT * FROM usuarios WHERE usuario = '$usuario' AND  password = '$password'  
           if($query->num_rows() > 0)  
           {  
                return true;  
           }  
           else  
           {  
                return false;      
           }  
      }  
 
    
}
